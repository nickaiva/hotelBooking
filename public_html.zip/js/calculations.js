/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*Navigation display only a section at a time*/
function showHide(id) {/*Navigate to each section as clicked*/
    if (!document.getElementById)
        return;
    var section = document.getElementById(id);
    //var allSections = document.getElementsByTagName("section");

    if (!section.style.display || section.style.display === "none") {
        /*show none or all*/
        /*
         for (i = 0; i < allSections.length; i++) {
         allSections[i].style.display = "none";// or block
         }
         */
        /*Show only the selected*/
        section.style.display = "block";
    } else {/*Necessary due to empty pages appearing initially when set="none" below*/
        section.style.display = "block";
    }

}
/*Dates validation*/
var start = "2020-07-01";
var end = "2020-07-10";

function validateNoEarlier() {

    var arrival = document.getElementById('arrival').value;
    if (arrival < start) {
        alert("You are too early");
        return false;
    }/*
     if ( arrival ===  start) {
     alert("You are ontime");
     return true;
     }*/
    if (end <= arrival) {
        alert("You arrive too late");
        return false;
    }
    return true;
}

function validateNoLater() {

    var departure = document.getElementById('departure').value;
    if (end < departure) {
        alert("You are too late");
        return false;
    }
    /* if ( departure ===  end) {
     alert("You depart on end day");
     return true;
     }*/
    if (departure < start) {
        alert("You leave too early");
        return false;
    }
    return true;
}

/*Determine days of stay*/

function getDays() {

    checkin = new Date(document.getElementById('arrival').value);
    checkout = new Date(document.getElementById('departure').value);
    console.log("Duration in days " + (checkout - checkin) / (1000 * 60 * 60 * 24));
    return (checkout - checkin) / (1000 * 60 * 60 * 24);
}
/* Single or double price depend on hotel*/
var beddingcosts;
function calculateBeddingCosts(nobeds) {

    var dailyCost = 1;

    var selection = document.querySelector('input[name="hotel"]:checked').value;
    console.log("nobeds " + nobeds);
    if (nobeds === 1) {
        switch (selection) {
            case "Amethist":
                dailyCost = 80;
                break;
            case "Boutique":
                dailyCost = 70;
                break;
            case "swissotel":
                dailyCost = 60;
                break;
            case "4seasons":
                dailyCost = 160;
                break;
        }
    } else {
        switch (selection) {
            case "Amethist":
                dailyCost = 100;
                break;
            case "Boutique":
                dailyCost = 90;
                break;
            case "swissotel":
                dailyCost = 80;
                break;
            case "4seasons":
                dailyCost = 180;
                break;
        }

    }


    var beddingcosts = getDays() * dailyCost;
    document.getElementById("beddingcosts").value = beddingcosts;
    console.log("beddingcosts " + beddingcosts);
    return beddingcosts;
}
/*Meal list prices depend on the hotel selection*/
function presentMealCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("Both").innerHTML = "Both 20€";
            document.getElementById("Lunch").innerHTML = "Lunch 25€";
            document.getElementById("Dinner").innerHTML = "Dinner 15€";
            document.getElementById("Both").value = 20;
            document.getElementById("Lunch").value = 25;
            document.getElementById("Dinner").value = 15;

            break;
        case "Boutique":
            document.getElementById("Both").innerHTML = "Both 40€";
            document.getElementById("Lunch").innerHTML = "Lunch 25€";
            document.getElementById("Dinner").innerHTML = "Dinner 20€";
            document.getElementById("Both").value = 40;
            document.getElementById("Lunch").value = 25;
            document.getElementById("Dinner").value = 20;
            break;
        case "swissotel":
            document.getElementById("Both").innerHTML = "Both 35€";
            document.getElementById("Lunch").innerHTML = "Lunch 25€";
            document.getElementById("Dinner").innerHTML = "Dinner 15€";
            document.getElementById("Both").value = 35;
            document.getElementById("Lunch").value = 25;
            document.getElementById("Dinner").value = 15;
            break;
        case "4seasons":
            document.getElementById("Both").innerHTML = "Both 60€";
            document.getElementById("Lunch").innerHTML = "Lunch 35€";
            document.getElementById("Dinner").innerHTML = "Dinner 35€";
            document.getElementById("Both").value = 60;
            document.getElementById("Lunch").value = 35;
            document.getElementById("Dinner").value = 35;
            break;
    }

}
function presentMealPlaceCosts() {

    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("terrace").innerHTML = "Terrace 5€";
            document.getElementById("room").innerHTML = "Room 10€";
            document.getElementById("terrace").value = 5;
            document.getElementById("room").value = 10;
            break;
        case "Boutique":
            document.getElementById("terrace").innerHTML = "Terrace 10€";
            document.getElementById("room").innerHTML = "Room 15€";
            document.getElementById("terrace").value = 10;
            document.getElementById("room").value = 15;
            break;
        case "swissotel":
            document.getElementById("terrace").innerHTML = "Terrace 15€";
            document.getElementById("room").innerHTML = "Room 20€";
            document.getElementById("terrace").value = 15;
            document.getElementById("room").value = 20;
            break;
        case "4seasons":
            document.getElementById("terrace").innerHTML = "Terrace 20€";
            document.getElementById("room").innerHTML = "Room 30€";
            document.getElementById("terrace").value = 20;
            document.getElementById("room").value = 30;
            break;
    }
}
function presentSafeCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("jc").innerHTML = "Both 20€";
            document.getElementById("jewelry").innerHTML = "Jewelry 25€";
            document.getElementById("cash").innerHTML = "Cash 15€";
            document.getElementById("jc").value = 20;
            document.getElementById("jewelry").value = 25;
            document.getElementById("cash").value = 15;
            break;
        case "Boutique":
            document.getElementById("jc").innerHTML = "Both 30€";
            document.getElementById("jewelry").innerHTML = "Jewelry 25€";
            document.getElementById("cash").innerHTML = "Cash 15€";
            document.getElementById("jc").value = 30;
            document.getElementById("jewelry").value = 25;
            document.getElementById("cash").value = 15;
            break;
        case "swissotel":
            document.getElementById("jc").innerHTML = "Both 40€";
            document.getElementById("jewelry").innerHTML = "Jewelry 25€";
            document.getElementById("cash").innerHTML = "Cash 15€";
            document.getElementById("jc").value = 40;
            document.getElementById("jewelry").value = 25;
            document.getElementById("cash").value = 15;
            break;
        case "4seasons":
            document.getElementById("jc").innerHTML = "Both 35€";
            document.getElementById("jewelry").innerHTML = "Jewelry 25€";
            document.getElementById("cash").innerHTML = "Cash 15€";
            document.getElementById("jc").value = 35;
            document.getElementById("jewelry").value = 25;
            document.getElementById("cash").value = 15;
            break;
    }
}
function presentTVCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("tvcs").innerHTML = "Both 15€";
            document.getElementById("cable").innerHTML = "Cable 15€";
            document.getElementById("sat").innerHTML = "Satellite 5€";
            document.getElementById("tvcs").value = 15;
            document.getElementById("cable").value = 15;
            document.getElementById("sat").value = 5;
            break;
        case "Boutique":
            document.getElementById("tvcs").innerHTML = "Both 30€";
            document.getElementById("cable").innerHTML = "Cable 25€";
            document.getElementById("sat").innerHTML = "Satellite 15€";
            document.getElementById("tvcs").value = 30;
            document.getElementById("cable").value = 25;
            document.getElementById("sat").value = 15;
            break;
        case "swissotel":
            document.getElementById("tvcs").innerHTML = "Both 30€";
            document.getElementById("cable").innerHTML = "Cable 15€";
            document.getElementById("sat").innerHTML = "Satellite 15€";
            document.getElementById("tvcs").value = 30;
            document.getElementById("cable").value = 15;
            document.getElementById("sat").value = 15;
            break;
        case "4seasons":
            document.getElementById("tvcs").innerHTML = "Both 45€";
            document.getElementById("cable").innerHTML = "Cable 25€";
            document.getElementById("sat").innerHTML = "Satellite 25€";
            document.getElementById("tvcs").value = 45;
            document.getElementById("cable").value = 25;
            document.getElementById("sat").value = 25;
            break;
    }
}

function presentNetAccessCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("ew").innerHTML = "Both 25€";
            document.getElementById("ethern").innerHTML = "Ethernet 15€";
            document.getElementById("wireless").innerHTML = "Wireless 15€";
            document.getElementById("ew").value = 25;
            document.getElementById("ethern").value = 15;
            document.getElementById("wireless").value = 15;
            break;
        case "Boutique":
            document.getElementById("ew").innerHTML = "Both 10€";
            document.getElementById("ethern").innerHTML = "Ethernet 5€";
            document.getElementById("wireless").innerHTML = "Wireless 5€";
            document.getElementById("ew").value = 10;
            document.getElementById("ethern").value = 5;
            document.getElementById("wireless").value = 5;
            break;
        case "swissotel":
            document.getElementById("ew").innerHTML = "Both 20€";
            document.getElementById("ethern").innerHTML = "Ethernet 15€";
            document.getElementById("wireless").innerHTML = "Wireless 5€";
            document.getElementById("ew").value = 20;
            document.getElementById("ethern").value = 15;
            document.getElementById("wireless").value = 5;
            break;
        case "4seasons":
            document.getElementById("ew").innerHTML = "Both 35€";
            document.getElementById("ethern").innerHTML = "Ethernet 25€";
            document.getElementById("wireless").innerHTML = "Wireless 15€";
            document.getElementById("ew").value = 35;
            document.getElementById("ethern").value = 25;
            document.getElementById("wireless").value = 15;
            break;
    }
}

function presentBarCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("softalco").innerHTML = "Both 25€";
            document.getElementById("soft").innerHTML = "Softdrinks 15€";
            document.getElementById("alcoh").innerHTML = "Alcoholic 15€";
            document.getElementById("softalco").value = 25;
            document.getElementById("soft").value = 15;
            document.getElementById("alcoh").value = 15;
            break;
        case "Boutique":
            document.getElementById("softalco").innerHTML = "Both 35€";
            document.getElementById("soft").innerHTML = "Softdrinks 15€";
            document.getElementById("alcoh").innerHTML = "Alcoholic 25€";
            document.getElementById("softalco").value = 35;
            document.getElementById("soft").value = 15;
            document.getElementById("alcoh").value = 25;
            break;
        case "swissotel":
            document.getElementById("softalco").innerHTML = "Both 45€";
            document.getElementById("soft").innerHTML = "Softdrinks 15€";
            document.getElementById("alcoh").innerHTML = "Alcoholic 35€";
            document.getElementById("softalco").value = 45;
            document.getElementById("soft").value = 15;
            document.getElementById("alcoh").value = 35;
            break;
        case "4seasons":
            document.getElementById("softalco").innerHTML = "Both 65€";
            document.getElementById("soft").innerHTML = "Softdrinks 25€";
            document.getElementById("alcoh").innerHTML = "Alcoholic 45€";
            document.getElementById("softalco").value = 65;
            document.getElementById("soft").value = 25;
            document.getElementById("alcoh").value = 45;
            break;
    }
}

function presentWashingCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("launiron").innerHTML = "Both 25€";
            document.getElementById("laund").innerHTML = "Laundry 15€";
            document.getElementById("iron").innerHTML = "Ironing 15€";
            document.getElementById("launiron").value = 25;
            document.getElementById("laund").value = 15;
            document.getElementById("iron").value = 15;
            break;
        case "Boutique":
            document.getElementById("launiron").innerHTML = "Both 35€";
            document.getElementById("laund").innerHTML = "Laundry 15€";
            document.getElementById("iron").innerHTML = "Ironing 25€";
            document.getElementById("launiron").value = 35;
            document.getElementById("laund").value = 15;
            document.getElementById("iron").value = 25;
            break;
        case "swissotel":
            document.getElementById("launiron").innerHTML = "Both 45€";
            document.getElementById("laund").innerHTML = "Laundry 15€";
            document.getElementById("iron").innerHTML = "Ironing 35€";
            document.getElementById("launiron").value = 45;
            document.getElementById("laund").value = 15;
            document.getElementById("iron").value = 35;
            break;
        case "4seasons":
            document.getElementById("launiron").innerHTML = "Both 65€";
            document.getElementById("laund").innerHTML = "Laundry 25€";
            document.getElementById("iron").innerHTML = "Ironing 45€";
            document.getElementById("launiron").value = 65;
            document.getElementById("laund").value = 25;
            document.getElementById("iron").value = 45;
            break;
    }
}
function presentRecreatinalCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("sauspa").innerHTML = "Both 25€";
            document.getElementById("sau").innerHTML = "Sauna 15€";
            document.getElementById("spa").innerHTML = "Spa 15€";
            document.getElementById("sauspa").value = 25;
            document.getElementById("sau").value = 15;
            document.getElementById("spa").value = 15;
            break;
        case "Boutique":
            document.getElementById("sauspa").innerHTML = "Both 35€";
            document.getElementById("sau").innerHTML = "Sauna 15€";
            document.getElementById("spa").innerHTML = "Spa 25€";
            document.getElementById("sauspa").value = 35;
            document.getElementById("sau").value = 15;
            document.getElementById("spa").value = 25;
            break;
        case "swissotel":
            document.getElementById("sauspa").innerHTML = "Both 45€";
            document.getElementById("sau").innerHTML = "Sauna 15€";
            document.getElementById("spa").innerHTML = "Spa 35€";
            document.getElementById("sauspa").value = 45;
            document.getElementById("sau").value = 15;
            document.getElementById("spa").value = 35;
            break;
        case "4seasons":
            document.getElementById("sauspa").innerHTML = "Both 65€";
            document.getElementById("sau").innerHTML = "Sauna 25€";
            document.getElementById("spa").innerHTML = "Spa 45€";
            document.getElementById("sauspa").value = 65;
            document.getElementById("sau").value = 25;
            document.getElementById("spa").value = 45;
            break;
    }
}

function presentSportCosts() {
    var selection = document.querySelector('input[name="hotel"]:checked').value;
    switch (selection) {
        case "Amethist":
            document.getElementById("gpool").innerHTML = "Both 25€";
            document.getElementById("gym").innerHTML = "Gym 15€";
            document.getElementById("pool").innerHTML = "Pool 15€";
            document.getElementById("gpool").value = 25;
            document.getElementById("gym").value = 15;
            document.getElementById("pool").value = 15;
            break;
        case "Boutique":
            document.getElementById("gpool").innerHTML = "Both 30€";
            document.getElementById("gym").innerHTML = "Gym 15€";
            document.getElementById("pool").innerHTML = "Pool 15€";
            document.getElementById("gpool").value = 30;
            document.getElementById("gym").value = 15;
            document.getElementById("pool").value = 15;
            break;
        case "swissotel":
            document.getElementById("gpool").innerHTML = "Both 45€";
            document.getElementById("gym").innerHTML = "Gym 25€";
            document.getElementById("pool").innerHTML = "Pool 25€";
            document.getElementById("gpool").value = 45;
            document.getElementById("gym").value = 25;
            document.getElementById("pool").value = 25;
            break;
        case "4seasons":
            document.getElementById("gpool").innerHTML = "Both 35€";
            document.getElementById("gym").innerHTML = "Gym 15€";
            document.getElementById("pool").innerHTML = "Pool 25€";
            document.getElementById("gpool").value = 35;
            document.getElementById("gym").value = 15;
            document.getElementById("pool").value = 25;
            break;
    }
}

/*Handles onmouse over images showing popup message*/
var mycode1 = document.getElementById("image1");

mycode1.onmouseover = function () {
    var checkbox1 = document.getElementById("checkbox1");
    checkbox1.classList.remove('hidden');
    checkbox1.classList.add("shown");
};

mycode1.onmouseout = function () {
    var checkbox1 = document.getElementById("checkbox1");
    checkbox1.classList.remove('shown');
    checkbox1.classList.add("hidden");
};

var mycode2 = document.getElementById("image2");

mycode2.onmouseover = function () {
    var checkbox2 = document.getElementById("checkbox2");
    checkbox2.classList.remove('hidden');
    checkbox2.classList.add("shown");
};

mycode2.onmouseout = function () {
    var checkbox2 = document.getElementById("checkbox2");
    checkbox2.classList.remove('shown');
    checkbox2.classList.add("hidden");
};

var mycode3 = document.getElementById("image3");

mycode3.onmouseover = function () {
    var checkbox3 = document.getElementById("checkbox3");
    checkbox3.classList.remove('hidden');
    checkbox3.classList.add("shown");
};

mycode3.onmouseout = function () {
    var checkbox3 = document.getElementById("checkbox3");
    checkbox3.classList.remove('shown');
    checkbox3.classList.add("hidden");
};

var mycode4 = document.getElementById("image4");

mycode4.onmouseover = function () {
    var checkbox4 = document.getElementById("checkbox4");
    checkbox4.classList.remove('hidden');
    checkbox4.classList.add("shown");
};

mycode4.onmouseout = function () {
    var checkbox4 = document.getElementById("checkbox4");
    checkbox4.classList.remove('shown');
    checkbox4.classList.add("hidden");
};


function showCVV2Feedback() {
    var cvv2feedback = document.getElementById("cvv2feedback");
    
    cvv2feedback.innerHTML = "The 3 digits at the signature side of the card";
}


/*Disabling inputs upon next button clicked */
function disableBookingFormFields() {
    /* dates book */
    var form = document.getElementById("bookForm");
    var allElements = form.elements;
    for (var i = 0, l = allElements.length; i < l; ++i) {
        //allElements[i].readOnly = true; 
        allElements[i].disabled = true;
    }
}
function disableOptionsFormFields() {
    /*Amenities extra options*/
    var form = document.getElementById("optionsForm");
    var allElements = form.elements;
    for (var i = 0, l = allElements.length; i < l; ++i) {
        //allElements[i].readOnly = true; 
        allElements[i].disabled = true;
    }
}

function calculateCosts() {

    var beddingcosts = 0;
    var optionalCosts = 0;
    var totalCosts = 0;

    beddingcosts = document.getElementById('beddingcosts').value;
    optionalCosts = document.getElementById('optionalcosts').value;
    totalCosts = parseFloat(beddingcosts);

    var meals = document.getElementById('meals').value;
    var mealplace = document.getElementById('mealsplace').value;
    var tvcosts = document.getElementById('tvoptions').value;
    var netcosts = document.getElementById('internetoptions').value;
    var barcosts = document.getElementById('baroptions').value;
    var laundrycosts = document.getElementById('laundryoptions').value;
    var recreationcosts = document.getElementById('recreationaloptions').value;
    var exercisecosts = document.getElementById('sportoptions').value;
    var safeoptions = document.getElementById('safeoptions').value;

    optionalCosts = parseFloat(tvcosts) + parseFloat(meals) + parseFloat(mealplace) + parseFloat(netcosts)
            + parseFloat(barcosts) + parseFloat(laundrycosts) + parseFloat(recreationcosts) +
            parseFloat(exercisecosts) + parseFloat(safeoptions);
    totalCosts += optionalCosts;
    console.log("totalCosts:" + parseFloat(totalCosts));
    document.getElementById('optionalcosts').value = optionalCosts;
    document.getElementById('totalCosts').value = totalCosts;
    return totalCosts;
}
/*4 digit number*/
function generateNewRandom() {
    var random1 = Math.floor(Math.random() * 10);
    var random2 = Math.floor(Math.random() * 10);
    var random3 = Math.floor(Math.random() * 10);
    var random4 = Math.floor(Math.random() * 10);
    var random = random1.toString() + random2.toString() + random3.toString() + random4.toString();
    //console.log("random " + random);
    document.getElementById('random').value = random;
}
function validateUserInput() {
    var random = document.getElementById('random').value;
    var verification = document.getElementById('verification').value;
    if (verification !== random) {
        alert("Verification failed");
        document.getElementById('random').value = 0;
        return false;
    }
    alert("Verification passed");
    console.log("verified");
    return true;
}
function checkCreditcardno() {
    var creditcardno = document.getElementById("creditcardno").value;
    if (creditcardno.length !== 16) {
        alert("The card number should be 16 digits long!");
        return false;
    } else
        return true;
}
